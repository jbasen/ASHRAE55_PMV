﻿using System;
using System.Text;
using Crestron.SimplSharp;
using System.Collections.Generic;

namespace ASHRAE55_PMV_Calc
{
	#region Delegates
	public delegate void DelegateFn(SimplSharpString Room_Name_P, short Air_Temperature_P, short Ceiling_Fan_Speed_Selection_P);
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};

	enum Temperature_Format_Options
	{
		Celsius,
		Fahrenheit
	};

	enum Air_Temperature_Multiplier_Options
	{
		x1,
		x10
	};

	enum HVAC_Mode_Options
	{
		Off,
		Heat,
		Cool
	};
	#endregion

	public class ASHRAE55_PMV
	{
		public DelegateFn callback_fn { get; set; }

		#region Declarations
		private static Debug_Options Debug;
		private static Temperature_Format_Options Temperature_Format;
		private static Air_Temperature_Multiplier_Options Temperature_Multiplier;
		private HVAC_Mode_Options HVAC_Mode = HVAC_Mode_Options.Off;
		string Room_Name = "";
		double Minimum_Temperature_Set_Point = 60;
		double Maximum_Temperature_Set_Point = 80;
		private List<double> Ceiling_Fan_Speed = new List<double>();
		#endregion

		public ASHRAE55_PMV()
		{
		}

		//****************************************************************************************
		// 
		//  System_Initialize	-	Initialization
		// 
		//****************************************************************************************
		public void System_Initialize(short Temperature_Format, short Temperature_Multiplier, short Debug)
		{
			Set_Debug_Message_Output(Debug);

			#region Temperature_Format
			switch (Temperature_Format)
			{
				case 0:
					ASHRAE55_PMV.Temperature_Format = Temperature_Format_Options.Celsius;
					break;

				case 1:
					ASHRAE55_PMV.Temperature_Format = Temperature_Format_Options.Fahrenheit;
					break;

				default:
					Debug_Message("System_Initialize", "Unsupported Temperature Format = " + Temperature_Format);
					Debug_Message("System_Initialize", "Defaulting Temperature Format to Fahrenheit");
					ASHRAE55_PMV.Temperature_Format = Temperature_Format_Options.Fahrenheit;
					break;
			}
			#endregion

			#region Temperature_Multiplier
			switch (Temperature_Multiplier)
			{
				case 1:
					ASHRAE55_PMV.Temperature_Multiplier = Air_Temperature_Multiplier_Options.x1;
					break;

				case 10:
					ASHRAE55_PMV.Temperature_Multiplier = Air_Temperature_Multiplier_Options.x10;
					break;

				default:
					Debug_Message("System_Initialize", "Unsupported Temperature Multiplier = " + Temperature_Multiplier);
					Debug_Message("System_Initialize", "Defaulting Temperature Multiplier to x1");
					ASHRAE55_PMV.Temperature_Multiplier = Air_Temperature_Multiplier_Options.x1;
					break;
			}
			#endregion

			Debug_Message("System_Initialize", "SUCCESS");
		}

		//****************************************************************************************
		// 
		//  Room_Initialize	-	Initialization
		// 
		//****************************************************************************************
		public void Room_Initialize(string Room_Name, short Minimum_Temperature_Set_Point, short Maximum_Temperature_Set_Point,
			short Ceiling_Fan_Speed_1_x10, short Ceiling_Fan_Speed_2_x10, short Ceiling_Fan_Speed_3_x10, short Ceiling_Fan_Speed_4_x10, 
			short Ceiling_Fan_Speed_5_x10)
		{
			#region Save Parameters
			this.Room_Name = Room_Name;
			this.Minimum_Temperature_Set_Point = Minimum_Temperature_Set_Point;
			this.Maximum_Temperature_Set_Point = Maximum_Temperature_Set_Point;

			#region Create Ceiling Fan Speed List and Save Current Speed
			//Save Each Speed to a List
			Ceiling_Fan_Speed.Add(0); //off
			if (Ceiling_Fan_Speed_1_x10 != 0)
			{
				Ceiling_Fan_Speed.Add(Convert.ToDouble(Ceiling_Fan_Speed_1_x10) / 10);
			}

			if (Ceiling_Fan_Speed_2_x10 != 0)
			{
				Ceiling_Fan_Speed.Add(Convert.ToDouble(Ceiling_Fan_Speed_2_x10) / 10);
			}

			if (Ceiling_Fan_Speed_3_x10 != 0)
			{
				Ceiling_Fan_Speed.Add(Convert.ToDouble(Ceiling_Fan_Speed_3_x10) / 10);
			}

			if (Ceiling_Fan_Speed_4_x10 != 0)
			{
				Ceiling_Fan_Speed.Add(Convert.ToDouble(Ceiling_Fan_Speed_4_x10) / 10);
			}

			if (Ceiling_Fan_Speed_5_x10 != 0)
			{
				Ceiling_Fan_Speed.Add(Convert.ToDouble(Ceiling_Fan_Speed_5_x10) / 10);
			}
			#endregion
			#endregion

			Debug_Message("Room_Initialize", "SUCCESS - " + Room_Name);
		}

		//****************************************************************************************
		// 
		//  Find_Optimal_Room_Settings	-	Find the most efficient settings based on desired
		//									comfort 
		// 
		//****************************************************************************************
		public void Find_Optimal_Room_Settings(short Desired_PMV_x10, short Current_Air_Temperature, short Humidity_Percent, 
			short Activity, short Clothing_Type, short Maximum_Acceptable_PMV_x10, short Minimum_Acceptable_PMV_x10)
		{
			double Current_Air_Temp;
			short Optimal_Ceiling_Fan_Speed_Selection;
			double Optimal_Air_Temperature;
			double Relative_Humidity = Convert.ToDouble(Humidity_Percent);

			#region Calculate Necessary Data Elements
			double Desired_PMV = Convert.ToDouble(Desired_PMV_x10) / 10;
			double Maximum_Acceptable_PMV = Convert.ToDouble(Maximum_Acceptable_PMV_x10) / 10;
			double Minimum_Acceptable_PMV = Convert.ToDouble(Minimum_Acceptable_PMV_x10) / 10;
			double Metabolic_Rate = Get_Metabolic_Rate(Activity);
			double Clothing = Get_Clothing(Clothing_Type);
			#endregion

			#region Adjust for Temperature Multiplier
			if (Temperature_Multiplier == Air_Temperature_Multiplier_Options.x1)
			{
				Current_Air_Temp = Convert.ToDouble(Current_Air_Temperature);
			}
			else
			{
				Current_Air_Temp = Convert.ToDouble(Current_Air_Temperature) / 10;
			}
			#endregion

			Debug_Message("Find_Optimal_Room_Settings", "Desired_PMV = " + Desired_PMV + ", Current_Air_Temperature = " + Current_Air_Temp +
				", Relative_Humidity = " + Relative_Humidity + ", Metabolic_Rate = " + Metabolic_Rate + ", Clothing = " + Clothing);

			#region Optimize for Ceiling Fan if HVAC set to cool or off and a ceiling fan is installed
			if ((HVAC_Mode != HVAC_Mode_Options.Heat) && (Ceiling_Fan_Speed.Count > 1))
			{
				Optimal_Ceiling_Fan_Speed_Selection = Find_Optimal_Fan_Speed(Desired_PMV, Current_Air_Temp, Humidity_Percent, Metabolic_Rate, Clothing);
			}
			else
			{
				Optimal_Ceiling_Fan_Speed_Selection = 0;
			}
			Debug_Message("Find_Optimal_Room_Settings", "Optimal_Ceiling_Fan_Speed_Selection = " + Optimal_Ceiling_Fan_Speed_Selection);
			#endregion

			#region Optmize HVAC Set Point
			if (HVAC_Mode != HVAC_Mode_Options.Off)
			{
				Optimal_Air_Temperature = Find_Optimal_Temp(Desired_PMV, Ceiling_Fan_Speed[Optimal_Ceiling_Fan_Speed_Selection], Relative_Humidity, Metabolic_Rate, Clothing);
				Debug_Message("Find_Optimal_Room_Settings", "Optimal_Air_Temperature = " + Optimal_Air_Temperature);
			}
			else
			{ 
				Optimal_Air_Temperature = -1;
			}
			#endregion

			#region Pass Settings Back to Simpl
			if (Temperature_Multiplier == Air_Temperature_Multiplier_Options.x10)
			{
				Optimal_Air_Temperature *= 10;
				Optimal_Air_Temperature = Math.Round(Optimal_Air_Temperature, 0);
			}
			callback_fn(Room_Name, Convert.ToInt16(Optimal_Air_Temperature), Optimal_Ceiling_Fan_Speed_Selection);
			#endregion
		}

		//****************************************************************************************
		// 
		//  Find_Optimal_Fan_Speed	-	Find optimal speed for the ceiling fan in a room
		// 
		//****************************************************************************************
		private short Find_Optimal_Fan_Speed(double Selected_PMV, double Air_Temperature, double Relative_Humidity, 
			double Metabolic_Rate, double Clothing)
		{
			double Best_PMV_Difference = 500;
			double Best_PMV;
			double Best_Air_Speed = -1;

			//Loop through each ceiling fan speed setting
			foreach (double Air_Speed in Ceiling_Fan_Speed)
			{
				double PMV = Calc_PMV(Air_Temperature, Air_Speed, Relative_Humidity, Metabolic_Rate, Clothing);
				double d = Math.Abs(Selected_PMV - PMV);	//How close was this to the desired PMV
				if (d < Best_PMV_Difference)				//did this speed get us closer to the desired PMV?
				{
					#region Save Best Settings
					Best_PMV_Difference = d;
					Best_PMV = PMV;
					Best_Air_Speed = Air_Speed;
					#endregion
					Debug_Message("Find_Optimal_Fan_Speed", "Better PMV = " + PMV + ", Air_Speed = " + Air_Speed);

				}
				else
				{
					Debug_Message("Find_Optimal_Fan_Speed", "Worse PMV = " + PMV + ", Air_Speed = " + Air_Speed);
				}
			}

			return Convert.ToInt16(Ceiling_Fan_Speed.IndexOf(Best_Air_Speed));
		}

		//****************************************************************************************
		// 
		//  Find_Optimal_Temp	-	Compares PMV Values to Find the Optimal Set Point
		// 
		//****************************************************************************************
		private double Find_Optimal_Temp(double Selected_PMV, double Air_Speed, double Relative_Humidity, 
			double Metabolic_Rate, double Clothing)
		{
			double Best_PMV_Difference = 500;
			double Best_PMV;
			double Best_Air_Temp = -1;

			//Loop through all acceptable thermostat settings
			for (double Air_Temp = Minimum_Temperature_Set_Point; Air_Temp <= Maximum_Temperature_Set_Point; Air_Temp += .2)
			{
				double PMV = Calc_PMV(Air_Temp, Air_Speed, Relative_Humidity, Metabolic_Rate, Clothing);
				double d = Math.Abs(Selected_PMV - PMV);		//How close was this to the desired PMV
				if (d < Best_PMV_Difference)					//did this speed get us closer to the desired PMV?
				{
					#region Save Best Settings
					Best_PMV_Difference = d;
					Best_PMV = PMV;
					Best_Air_Temp = Air_Temp;
					#endregion
					Debug_Message("Find_Optimal_Temp", "Better PMV = " + PMV + ", Air_Temp = " + Air_Temp);

				}
				else
				{
					Debug_Message("Find_Optimal_Temp", "Worse PMV = " + PMV + ", Air_Temp = " + Air_Temp);
				}
			}
			return Best_Air_Temp;
		}

		//****************************************************************************************
		// 
		//  Calc_PMV	-	Calculate ASHRAE-55 PMV
		// 
		//****************************************************************************************
		private double Calc_PMV(double Air_Temperature, double Air_Speed, double Relative_Humidity, double Metabolic_Rate, double Clothing)
		{
			Debug_Message("Calc_PMV", "Air_Temperature = " + Air_Temperature + ", Air_Speed = " + Air_Speed + 
				", Relative_Humidity = " + Relative_Humidity + ", Metabolic_Rate = " + Metabolic_Rate + ", Clothing = " + Clothing);

			#region Temperature Conversion to Celsius
			if (Temperature_Format == Temperature_Format_Options.Fahrenheit)
			{
				Air_Temperature = Fahrenheit_To_Celsius(Air_Temperature);
			}
			#endregion

			double ta = Air_Temperature;			//Celsius
			double tr = ta;							//Mean Radiant Temperature.  See - https://www.linkedin.com/pulse/mean-radiant-temperature-generally-equal-air-stefano-schiavon/
			double vel = Air_Speed;					// m/s
			double rh = Relative_Humidity;			// %
			double met = Metabolic_Rate;			// met
			double clo = Clothing;					// clo
			double wme = 0;							//external work, assumed 0 met

			double pa = rh * 10 * Math.Exp(16.6536 - 4030.183 / (ta + 235));
            double icl = 0.155 * clo;				//Thermal insulation of the clothing in M2K/W
            double m = met * 58.15;					//Metabolic rate in W/M2
            double w = wme * 58.15;					//External work in W/M2
            double mw = m - w;						//Internal heat production in the human body

            double fcl = icl <= 0.078 ? (1 + (1.29 * icl)) : (1.05 + (0.645 * icl));

            //Heat transf. coeff. by forced convection
            double hcf = 12.1 * Math.Sqrt(vel);
            double taa = ta + 273;
            double tra = tr + 273;
            double tcla = taa + (35.5 - ta) / (3.5 * icl + 0.1);

            double p1 = icl * fcl;
            double p2 = p1 * 3.96;
            double p3 = p1 * 100;
            double p4 = p1 * taa;
            double p5 = 308.7 - 0.028 * mw + p2 * Math.Pow(tra / 100, 4);
            double xn = tcla / 100;
            double xf = tcla / 50;
            double eps = 0.00015;

            double hc = hcf;    //eliminate compile warning
            int n = 0;
            while (Math.Abs(xn - xf) > eps)
            {
                xf = (xf + xn) / 2;
                double hcn = 2.38 * Math.Pow(Math.Abs(100.0 * xf - taa), 0.25);
                hc = hcf > hcn ? hcf : hcn;
                xn = (p5 + p4 * hc - p2 * Math.Pow(xf, 4)) / (100 + p3 * hc);
                n++;
                if (n > 150) 
                {
					Debug_Message("Calc_PMV", "Max Iterations Exceeded");
                    return -100;
                }
            }

            double tcl = 100 * xn - 273;
            // Heat loss diff. through skin
            double hl1 = 3.05 * 0.001 * (5733 - (6.99 * mw) - pa);
            // Heat loss by sweating
            double hl2 = mw > 58.15 ? (0.42 * (mw - 58.15)) : 0;
            // Latent respiration heat loss
            double hl3 = 1.7 * 0.00001 * m * (5867 - pa);
            // Dry respiration heat loss
            double hL4 = 0.0014 * m * (34 - ta);
            // Heat loss by radiation
            double hl5 = 3.96 * fcl * (Math.Pow(xn, 4) - Math.Pow(tra / 100, 4));
            // Heat loss by convection
            double hl6 = fcl * hc * (tcl - ta);

            double ts = 0.303 * Math.Exp(-0.036 * m) + 0.028;
            double pmv = ts * (mw - hl1 - hl2 - hl3 - hL4 - hl5 - hl6);
            double ppd = 100.0 - 95.0 * Math.Exp(-0.03353 * Math.Pow(pmv, 4.0) - 0.2179 * Math.Pow(pmv, 2.0));
			Debug_Message("Calc_PMV", "PMV = " + pmv + ", PPD = " + ppd);
			return pmv;
		}

		//****************************************************************************************
		// 
		//  Set_HVAC_Mode	-	Set Current HVAC Mode
		// 
		//****************************************************************************************
		public void Set_HVAC_Mode(short HVAC_Mode)
		{
			switch (HVAC_Mode)
			{
				case 0:
					this.HVAC_Mode = HVAC_Mode_Options.Off;
					break;

				case 1:
					this.HVAC_Mode = HVAC_Mode_Options.Heat;
					break;

				case 2:
					this.HVAC_Mode = HVAC_Mode_Options.Cool;
					break;

				default:
					Debug_Message("System_Initialize", "Unsupported HVAC_Mode = " + HVAC_Mode);
					Debug_Message("System_Initialize", "Setting HVAC Mode to Off");
					this.HVAC_Mode = HVAC_Mode_Options.Off;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Get_Metabolic_Rate	-	Returns metabolic rate from activity
		// 
		//****************************************************************************************
		private double Get_Metabolic_Rate(short Activity)
		{
			double Metabolic_Rate = 0;

			switch (Activity)
			{
				case 1:				//Sleeping
					Metabolic_Rate = .7;
					break;

				case 2:				//Reclining
					Metabolic_Rate = .8;
					break;

				case 3:				//Seated, Quiet
					Metabolic_Rate = 1;
					break;

				case 4:				//Reading, Seated
					Metabolic_Rate = 1;
					break;

				case 5:				//Writing
					Metabolic_Rate = 1;
					break;

				case 6:				//Typing
					Metabolic_Rate = 1.1;
					break;

				case 7:				//Standing, Relaxed
					Metabolic_Rate = 1.2;
					break;

				case 8:				//Filing, Seated
					Metabolic_Rate = 1.2;
					break;

				case 9:				//Filing,m Standing
					Metabolic_Rate = 1.4;
					break;

				case 10:				//Walking About
					Metabolic_Rate = 1.7;
					break;

				case 11:				//Cooking
					Metabolic_Rate = 1.8;
					break;

				case 12:				//Walking 2mph
					Metabolic_Rate = 2;
					break;

				case 13:				//Lifting/Packing
					Metabolic_Rate = 2.1;
					break;

				case 14:				//Sitting, Heavy Limb Movements
					Metabolic_Rate = 2.2;
					break;

				case 15:				//Light Machine Work
					Metabolic_Rate = 2.2;
					break;

				case 16:				//House Cleaning
					Metabolic_Rate = 2.7;
					break;

				case 17:				//Dancing
					Metabolic_Rate = 3.4;
					break;

				case 18:				//Calisthenics
					Metabolic_Rate = 3.5;
					break;

				case 19:				//Walking 4mph
					Metabolic_Rate = 3.8;
					break;

				case 20:				//Heavy Machine Work
					Metabolic_Rate = 4;
					break;

				default:
					Debug_Message("Get_Metabolic_Rate", "Unknown Activity = " + Activity);
					Metabolic_Rate = 2.35;
					break;

			}

			Debug_Message("Get_Metabolic_Rate", "Activity = " + Activity + ", Metabolic_Rate = " + Metabolic_Rate);

			return Metabolic_Rate;
		}

		//****************************************************************************************
		// 
		//  Get_Clothing	-	Returns clothing from Clothing Type rate from activity
		// 
		//****************************************************************************************
		private double Get_Clothing(short Clothing_Type)
		{
			double Clothing = 0;

			switch (Clothing_Type)
			{
				case 1:				//Walking Shorts, Short-Sleeve Shirt
					Clothing = .36;
					break;

				case 2:				//Typical Summer Indoor Clothing
					Clothing = .5;
					break;

				case 3:				//Knee-Length Skirt, Short-Sleeve Shirt, Sandals, Underwear
					Clothing = .54;
					break;

				case 4:				//Trousers, Short-Sleeve Shirt, Socks, Shoes, Underwear
					Clothing = .57;
					break;

				case 5:				//Trousers, Long-Sleeve Shirt
					Clothing = .61;
					break;

				case 6:				//Knee-Length Skirt, Long-Sleeve Shirt, Full Slip
					Clothing = .67;
					break;

				case 7:				//Sweat Panbts, Long-Sleeve Sweatshirt
					Clothing = .74;
					break;

				case 8:				//Jacket, Trousers, Long-Sleeve Shirt
					Clothing = .96;
					break;

				case 9:				//Typical Winter Indoor Clothing
					Clothing = 1;
					break;

				default:
					Debug_Message("Get_Clothing", "Unknown Clothing Type = " + Clothing_Type);
					Clothing = .68;
					break;
			}
			Debug_Message("Get_Clothing", "Clothing Type = " + Clothing_Type + ", Clothing = " + Clothing);

			return Clothing;
		}

		//****************************************************************************************
		// 
		//  Celsius_To_Fahrenheit	-	Convert Temperaute in Celsius to Fahrenheit
		// 
		//****************************************************************************************
		private double Celsius_To_Fahrenheit(double Celsius)
		{
			return (Celsius * 1.8) + 32;
		}

		//****************************************************************************************
		// 
		//  Fahrenheit_To_Celsius	-	Convert Temperaute in Fahrenheit to Celsius
		// 
		//****************************************************************************************
		private double Fahrenheit_To_Celsius(double Fahrenheit)
		{
			return (Fahrenheit - 32) / 1.8;
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					ASHRAE55_PMV.Debug = Debug_Options.None;
					break;

				case 1:
					ASHRAE55_PMV.Debug = Debug_Options.Console;
					break;

				case 2:
					ASHRAE55_PMV.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					ASHRAE55_PMV.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 200;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("ASHRAE55_PMV - " + Name + " - " + Room_Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("ASHRAE55_PMV - " + Name + " - " + Room_Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}
}
